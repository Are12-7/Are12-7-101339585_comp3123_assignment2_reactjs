import './App.css';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import "../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"
import Navbar from './components/Navbar';
import Home from './components/Home';
import Add from './components/Add';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Edit from './components/Edit';
import Details from './components/Details';


function App() {
  return (
    <>
      <Navbar />
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home />} exact></Route>
          <Route path='/add' element={<Add />} exact></Route>
          <Route path='/edit/:eid' element={<Edit/>} exact></Route>
          <Route path='/view/:eid' element={<Details/>} exact></Route>
        </Routes>     
      </BrowserRouter>
    </>
  );
}

export default App;
