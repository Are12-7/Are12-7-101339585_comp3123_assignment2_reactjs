import React, { useState } from 'react';
import { useNavigate  } from 'react-router-dom';


const Add = () => {    

    const navigate = useNavigate();

    const [inpval, setINP] = useState({
        firstName: "",
        lastName: "",
        phoneNumber: "",
        email: ""
    })

    const setdata = (e) => {
        console.log(e.target.value);
        const { name, value } = e.target;
        setINP((preval) => {
            return {
                ...preval,
                [name]: value
            }
        })
    }   

    const addinpdata = async (e) => {
        e.preventDefault();

        const { firstName, lastName, phoneNumber, email } = inpval;

        const res = await fetch("/api/emp/employees/add", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                firstName, lastName, phoneNumber, email
            })
        });

        const data = await res.json();
        console.log(data);

        if (res.status === 422 || !data) {
            console.log("error ");
            alert("error");

        } else {
            alert("Employee added successfully");
            navigate("/");

        }
    }

    return (
        <div className='container'>
            <form className='mt-4'>
                <div className='row'>
                    <div className='mb-3 col-lg-6 col-md-6 col-12'>
                        <label className='form-label'>First Name</label>
                        <input type="text" value={inpval.firstName} onChange={setdata} className='form-control' name='firstName' id="exampleInputEmail1" aria-describedby="emailHelp" placeholder='First Name'/>
                    </div>
                    <div className='mb-3 col-lg-6 col-md-6 col-12'>
                        <label className='form-label' >Last Name</label>
                        <input type="text" value={inpval.lastName} onChange={setdata} className='form-control' id="exampleInputPassword1" placeholder='Last Name' name='lastName'/>
                    </div>
                    <div className='mb-3 col-lg-6 col-md-6 col-12'>
                        <label className='form-label' >Phone Number</label>
                        <input type="text" value={inpval.phoneNumber} onChange={setdata} className='form-control' id="exampleInputPassword1" placeholder='Phone Number' name='phoneNumber' />
                    </div>

                    <div className='mb-3 col-lg-6 col-md-12 col-12'>
                        <label className='form-label'>Email</label>
                        <input type="email" value={inpval.email} onChange={setdata} className='form-control' id="exampleInputPassword1" placeholder='Email' name='email' />
                    </div>       
                    <button type='submit' onClick={addinpdata} className='btn btn-primary'>Submit</button>
                </div>
            </form>
        </div>
    )
}
export default Add