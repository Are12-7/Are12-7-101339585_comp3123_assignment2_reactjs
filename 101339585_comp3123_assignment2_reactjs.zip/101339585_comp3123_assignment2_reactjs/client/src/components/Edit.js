import React, { useState, useEffect } from 'react'
import { useParams, useNavigate  } from 'react-router-dom';


const Edit = () => {


    const navigate = useNavigate();

    
    const [inpval, setINP] = useState({
        firstName: "",
        lastName: "",
        phoneNumber: "",
        email: ""
    })

    const setdata = (e) => {
        console.log(e.target.value);
        const { name, value } = e.target;
        setINP((preval) => {
            return {
                ...preval,
                [name]: value
            }
        })
    }   

    const { eid } = useParams('');
    console.log(eid);

    const getdata = async () => {

        const res = await fetch(`/api/emp/employees/${eid}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });

        const data = await res.json();
        console.log(data);

        if (res.status === 422 || !data) {
            console.log("error ");

        } else {
            setINP(data)
            console.log("Retrieving  data");
        }
    }

    useEffect(() => {
        getdata();
    }, [])

    //UPDATE
    const updateEmployee = async(e)=>{
        e.preventDefault();

        const {firstName,lastName,phoneNumber,email} = inpval;

        const res2 = await fetch(`/api/emp/employees/${eid}`,{
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body:JSON.stringify({
                firstName,lastName,phoneNumber,email
            })
        });

        const data2 = await res2.json();
        console.log(data2);

        if(res2.status === 422 || !data2){
            alert("fill out the form");
        } else {
            navigate("/");
            alert('Employee information updated');
        }

    }

    
    return (
        <div className='container'>
            <form className='mt-4'>
                <div className='row'>
                    <div className='mb-3 col-lg-6 col-md-6 col-12'>
                        <label className='form-label'>First Name</label>
                        <input type="text" value={inpval.firstName} onChange={setdata} className='form-control' name='firstName' id="exampleInputEmail1" aria-describedby="emailHelp" placeholder='First Name' />
                    </div>
                    <div className='mb-3 col-lg-6 col-md-6 col-12'>
                        <label className='form-label' >Last Name</label>
                        <input type="text" value={inpval.lastName} onChange={setdata} className='form-control' id="exampleInputPassword1" placeholder='Last Name' name='lastName' />
                    </div>
                    <div className='mb-3 col-lg-6 col-md-6 col-12'>
                        <label className='form-label' >Phone Number</label>
                        <input type="text" value={inpval.phoneNumber} onChange={setdata} className='form-control' id="exampleInputPassword1" placeholder='Phone Number' name='phoneNumber' />
                    </div>

                    <div className='mb-3 col-lg-6 col-md-12 col-12'>
                        <label className='form-label'>Email</label>
                        <input type="email" value={inpval.email} onChange={setdata} className='form-control' id="exampleInputPassword1" placeholder='Email' name='email' />
                    </div>
                    <button onClick={updateEmployee} className='btn btn-primary'>Submit</button>
                </div>
            </form>
        </div>
    )
}

export default Edit;