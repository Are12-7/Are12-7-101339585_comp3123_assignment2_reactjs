import React, { useState, useEffect } from 'react'
import RemoveRedEyeIcon from '@mui/icons-material/RemoveRedEye';
import EditIcon from '@mui/icons-material/Edit';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import { NavLink } from 'react-router-dom';

const Home = () => {

    const [getemployeedata, setAllEmployee] = useState([]);


    
    const getAll = async (e) => {
    
        const res = await fetch("/api/emp/employees", {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });

        const data = await res.json();
        console.log(data);

        if (res.status === 422 || !data) {
            console.log("error ");
        } else {
            setAllEmployee(data)
        }
    }

    useEffect(() => {
        getAll();
    }, [])


    //DELETE BUTTON
    const deleteEmployee = async (eid) => {

        const res2 = await fetch(`/api/emp/employees/${eid}`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        });

        const deletedata = await res2.json();
        console.log(deletedata);

        if (res2.status === 'undefined' || !deletedata) {
            console.log("error");
        } else {
            console.log("user deleted");
            getAll();
        }
    }
    
    return (
        <div className='mt-5'>
            <div className='container'>
                <div className='add_btn mt-2 mb-2'>
                    <NavLink to='/add' className='btn btn-primary' >Add Employee</NavLink>
                </div>
                <table className='table'>
                    <thead>
                        <tr className='table-dark'>
                            <th scope="col">Id</th>
                            <th scope="col">First Name</th>
                            <th scope="col">Last Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Phone Number</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            getemployeedata.map((element, eid) => {
                                return (
                                    <>
                                        <tr>
                                            <th scope="row">{eid + 1}</th>
                                            <td>{element.firstName}</td>
                                            <td>{element.lastName}</td>
                                            <td>{element.phoneNumber}</td>
                                            <td>{element.email}</td>
                                            <td className='d-flex justify-content-between'>
                                                <button className='btn btn-success'><RemoveRedEyeIcon /></button>
                                                <button className='btn btn-primary'><EditIcon /></button>
                                                <button className='btn btn-danger' onClick={() => deleteEmployee(element.eid)}><DeleteForeverIcon /></button>
                                            </td>
                                        </tr>
                                    </>
                                )
                            })
                        }
                    </tbody>
                </table>
            </div>
        </div>
    )
};

export default Home